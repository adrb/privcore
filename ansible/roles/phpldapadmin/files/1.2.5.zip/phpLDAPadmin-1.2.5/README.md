phpLDAPadmin
============

phpLDAPadmin - Web based LDAP administration tool


## Installation

[INSTALL](INSTALL.md)

## License

[LICENSE](LICENSE)
