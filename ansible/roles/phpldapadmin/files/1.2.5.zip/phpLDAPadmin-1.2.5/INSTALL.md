For install instructions in non-English languages, see the wiki:
    http://phpldapadmin.sourceforge.net

* Requirements

  phpLDAPadmin requires the following:
      a. A web server (Apache, IIS, etc).
      b. PHP 5.0.0 or newer (with LDAP support)

* To install

  1. Unpack the archive (if you're reading this, you already did that).
  2. Put the resulting 'phpldapadmin' directory somewhere in your webroot.
  3. Copy 'config.php.example' to 'config.php' and edit to taste (this is in the config/ directory).
  4. Then, point your browser to the phpldapadmin directory.

* For additional help

  See the wiki:
    http://phpldapadmin.sourceforge.net

  Join our mailing list: 
    https://lists.sourceforge.net/lists/listinfo/phpldapadmin-devel
