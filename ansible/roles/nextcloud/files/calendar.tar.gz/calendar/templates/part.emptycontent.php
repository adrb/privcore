<div id="emptycontent">
	<div class="icon-calendar-dark"></div>
	<h2><?php p($l->t('Calendar does not exist')); ?></h2>
	<p><?php p($l->t('Maybe you got a wrong link or the calendar was unshared?')); ?></p>
</div>
