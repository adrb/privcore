sessionStorage.removeItem('files_clipboard');
