<?php
$this->create('files_clipboard_ajax', 'ajax/clipboard.php')->actionInclude('files_clipboard/ajax/clipboard.php');