Description
-----------
Minimal clipboard feature for the files application. Allows to copy and move files between directories.

![](https://raw.githubusercontent.com/leizh/owncloud-files_clipboard/master/appinfo/nextcloud-clipboard.gif)

Installation
------------
Extract the [release](https://github.com/leizh/owncloud-files_clipboard/releases/latest) in your `apps` directory and rename it to `files_clipboard`.

License
-------
[GNU Affero General Public License](http://www.gnu.org/licenses/agpl-3.0.html)
