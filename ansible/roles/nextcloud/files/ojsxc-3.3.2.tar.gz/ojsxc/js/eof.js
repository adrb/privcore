/*!
 * ojsxc v3.3.2 - 2017-11-29
 * 
 * Copyright (c) 2017 Klaus Herberth <klaus@jsxc.org> <br>
 * Released under the MIT license
 * 
 * Please see http://www.jsxc.org/
 * 
 * @author Klaus Herberth <klaus@jsxc.org>
 * @version 3.3.2
 * @license MIT
 */

/**
 * This is a helper file for the concatenation.
 */
;