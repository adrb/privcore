<?php

namespace OCA\OJSXC\Exceptions;

class Exception extends \Exception
{
}
