<?php

namespace RainLoop\Providers\Storage\Enumerations;

class StorageType
{
	const USER = 1;
	const CONFIG = 2;
	const NOBODY = 3;
}
