<?php

namespace RainLoop\Enumerations;

class TimeFormat
{
	const F12 = '12';
	const F24 = '24';
}