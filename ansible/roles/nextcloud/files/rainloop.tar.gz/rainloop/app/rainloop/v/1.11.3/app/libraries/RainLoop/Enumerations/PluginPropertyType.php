<?php

namespace RainLoop\Enumerations;

class PluginPropertyType
{
	const STRING = 0;
	const INT = 1;
	const STRING_TEXT = 2;
	const PASSWORD = 3;
	const SELECTION = 4;
	const BOOL = 5;
}
