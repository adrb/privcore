<?php

namespace RainLoop\Providers\Filters\Enumerations;

class ConditionsType
{
	const ALL = 'All';
	const ANY = 'Any';
}
