<?php

namespace RainLoop\Providers\AddressBook;

interface AddressBookInterface
{
	/**
	 * @return bool
	 */
	public function IsSupported();
}